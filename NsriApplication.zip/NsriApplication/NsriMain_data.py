global alpha,q
global X10,Y10,X20,Y20,X30,Y30,X1d0,Y1d0,X2d0,Y2d0,X3d0,Y3d0














